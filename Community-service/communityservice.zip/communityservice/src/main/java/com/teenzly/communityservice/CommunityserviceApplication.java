package com.teenzly.communityservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommunityserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommunityserviceApplication.class, args);
	}

}
